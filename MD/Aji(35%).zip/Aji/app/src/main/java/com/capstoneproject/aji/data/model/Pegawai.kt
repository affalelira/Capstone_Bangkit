package com.capstoneproject.aji.data.model

data class Pegawai(
    val id_pegawai: Int?,
    val NIK: String,
    val TTL: String,
    val alamat: String,
    val jenis_kelamin: String,
    val no_wa: String,
    val no_rek: String,
    val agama: String,
    val posisi: String
)
